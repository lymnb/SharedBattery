var app = getApp();
Page({
  data: {
    latitude:'',  // latitude	纬度
    longitude:'', // longitude	经度
    markers:
    [
  {
    id: 0,
    latitude:36,
    longitude: 117,
    name: '酒店1',
    callout: {
      content: " 地点1",
      padding: 10,
      display: 'ALWAYS',
      textAlign: 'center',
      borderRadius: 10,
      borderWidth: 1,
    }

    
  },
  {
    id: 1,
    latitude: 35,
    longitude: 116,
    name: '酒店2',
    callout: {
      content: "地点2",
      padding: 10,
      display: 'ALWAYS',
      textAlign: 'center',
      borderRadius: 10,
      borderWidth: 1,
    }


  },
]
  },
  selectMarket: function (e) {
    console.log(e)
    var id = e.markerId
    console.log(id)
    wx.openLocation({
      latitude: this.data.markers[id].latitude,
      longitude: this.data.markers[id].longitude,
      name: this.data.markers[id].name,
    })
  },
  onLoad: function (options) {
    var that = this
    wx.getLocation({
      success: function (res) {
        console.log(res)
        that.setData({
          longitude: res.longitude,
          latitude: res.latitude
        })
      },
    })
    // 这里请求接口
  },
});

