Page({

  data: {
    avatar: '',
    name: ''
  },

  onShow: function () {

    this.setData({
      avatar: wx.getStorageSync('avatar') || 'https://s2.ax1x.com/2020/02/23/3lGKBT.jpg',
      name: wx.getStorageSync('name') || ''
    });

  },

  navTo: function (e) {
    wx.navigateTo({
      url: e.currentTarget.dataset.target == 'setting' ? '/pages/setting/setting' : '/pages/user/user'
    });
  },

  us: function () {
    wx.navigateTo({
      url: '/pages/about/about'
    })

  },

})